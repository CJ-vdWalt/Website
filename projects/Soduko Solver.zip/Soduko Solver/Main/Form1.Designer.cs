﻿namespace Soduko_Solver
{
    partial class Soduko_Solver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Soduko_Solver));
            this.clear_btn = new System.Windows.Forms.Button();
            this.solve_btn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.col1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soduko_pic = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soduko_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // clear_btn
            // 
            this.clear_btn.Font = new System.Drawing.Font("Arial", 16F);
            this.clear_btn.Location = new System.Drawing.Point(47, 475);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(171, 66);
            this.clear_btn.TabIndex = 1998;
            this.clear_btn.Text = "Clear";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // solve_btn
            // 
            this.solve_btn.Font = new System.Drawing.Font("Arial", 16F);
            this.solve_btn.Location = new System.Drawing.Point(47, 379);
            this.solve_btn.Name = "solve_btn";
            this.solve_btn.Size = new System.Drawing.Size(171, 66);
            this.solve_btn.TabIndex = 90;
            this.solve_btn.Text = "Solve";
            this.solve_btn.UseVisualStyleBackColor = true;
            this.solve_btn.Click += new System.EventHandler(this.solve_btn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeight = 29;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col1,
            this.col2,
            this.col3,
            this.col4,
            this.col5,
            this.col6,
            this.col7,
            this.col8,
            this.col9});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(281, 21);
            this.dataGridView1.MaximumSize = new System.Drawing.Size(560, 530);
            this.dataGridView1.MinimumSize = new System.Drawing.Size(560, 530);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 100;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(560, 530);
            this.dataGridView1.TabIndex = 1;
            // 
            // col1
            // 
            this.col1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col1.DividerWidth = 2;
            this.col1.HeaderText = "Column1";
            this.col1.MaxInputLength = 1;
            this.col1.MinimumWidth = 6;
            this.col1.Name = "col1";
            // 
            // col2
            // 
            this.col2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col2.DividerWidth = 2;
            this.col2.HeaderText = "Column1";
            this.col2.MaxInputLength = 1;
            this.col2.MinimumWidth = 6;
            this.col2.Name = "col2";
            // 
            // col3
            // 
            this.col3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col3.DividerWidth = 2;
            this.col3.HeaderText = "Column1";
            this.col3.MaxInputLength = 1;
            this.col3.MinimumWidth = 6;
            this.col3.Name = "col3";
            // 
            // col4
            // 
            this.col4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col4.DividerWidth = 2;
            this.col4.HeaderText = "Column1";
            this.col4.MaxInputLength = 1;
            this.col4.MinimumWidth = 6;
            this.col4.Name = "col4";
            // 
            // col5
            // 
            this.col5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col5.DividerWidth = 2;
            this.col5.HeaderText = "Column1";
            this.col5.MaxInputLength = 1;
            this.col5.MinimumWidth = 6;
            this.col5.Name = "col5";
            // 
            // col6
            // 
            this.col6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col6.DividerWidth = 2;
            this.col6.HeaderText = "Column1";
            this.col6.MaxInputLength = 1;
            this.col6.MinimumWidth = 6;
            this.col6.Name = "col6";
            // 
            // col7
            // 
            this.col7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col7.DividerWidth = 2;
            this.col7.HeaderText = "Column1";
            this.col7.MaxInputLength = 1;
            this.col7.MinimumWidth = 6;
            this.col7.Name = "col7";
            // 
            // col8
            // 
            this.col8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col8.DividerWidth = 2;
            this.col8.HeaderText = "Column1";
            this.col8.MaxInputLength = 1;
            this.col8.MinimumWidth = 6;
            this.col8.Name = "col8";
            // 
            // col9
            // 
            this.col9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.col9.DividerWidth = 2;
            this.col9.HeaderText = "Column1";
            this.col9.MaxInputLength = 1;
            this.col9.MinimumWidth = 6;
            this.col9.Name = "col9";
            // 
            // soduko_pic
            // 
            this.soduko_pic.Image = global::Soduko_Solver.Properties.Resources.Soduko;
            this.soduko_pic.Location = new System.Drawing.Point(12, 21);
            this.soduko_pic.Name = "soduko_pic";
            this.soduko_pic.Size = new System.Drawing.Size(263, 352);
            this.soduko_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.soduko_pic.TabIndex = 1999;
            this.soduko_pic.TabStop = false;
            // 
            // Soduko_Solver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(872, 563);
            this.Controls.Add(this.soduko_pic);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.solve_btn);
            this.Controls.Add(this.clear_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(890, 610);
            this.MinimumSize = new System.Drawing.Size(890, 610);
            this.Name = "Soduko_Solver";
            this.Text = "Soduko Solver";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soduko_pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.Button solve_btn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col2;
        private System.Windows.Forms.DataGridViewTextBoxColumn col3;
        private System.Windows.Forms.DataGridViewTextBoxColumn col4;
        private System.Windows.Forms.DataGridViewTextBoxColumn col5;
        private System.Windows.Forms.DataGridViewTextBoxColumn col6;
        private System.Windows.Forms.DataGridViewTextBoxColumn col7;
        private System.Windows.Forms.DataGridViewTextBoxColumn col8;
        private System.Windows.Forms.DataGridViewTextBoxColumn col9;
        private System.Windows.Forms.PictureBox soduko_pic;
    }
}

