﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soduko_Solver
{
    public partial class Soduko_Solver : Form
    {
        private const int Size = 9;
        public Soduko_Solver()
        {
            InitializeComponent();
            Clear();
            dataGridView1.ScrollBars = ScrollBars.None;
            dataGridView1.AllowUserToAddRows = false;
        }

        private String[,] final;

        public String[,] getBoard()
        {
            string[,] rows = new string[Size,Size];
            
            for(int i = 0; i < Size; i++)
            {
                for(int j = 0; j < Size; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value == null)
                    {
                        rows[i, j] = ".";
                    }
                    else
                    {
                        rows[i, j] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
            }

            HashSet<string> check = new HashSet<string>();
            for(int i = 0; i < Size; i++)
            {
                for(int j = 0; j < Size; j++)
                {
                    string curVal = rows[i, j].ToString();
                    if(curVal != ".")
                    {
                        if(!check.Add(curVal + " found in row " + i) ||
                            !check.Add(curVal + " found in col " + j) ||
                             !check.Add(curVal + "found in box " + i / 3 + "_" + j / 3)
                                  )
                        {
                            return null;
                        }
                    }
                }
            }
            return rows;
        }

        public void Reload()
        {
            for(int i = 0; i < 9; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].DividerHeight = 2;
            }

            dataGridView1.Rows[2].DividerHeight = dataGridView1.Rows[5].DividerHeight = dataGridView1.Rows[8].DividerHeight = 5;
            dataGridView1.Columns[2].DividerWidth = dataGridView1.Columns[5].DividerWidth = dataGridView1.Columns[8].DividerWidth = 5;

            for(int i = 0; i < 9; i++)
            {
                dataGridView1.Rows[i].Height = 50;
                dataGridView1.Columns[i].Width = 50;
            }
        }

        public void Clear()
        {
            dataGridView1.Rows.Clear();
            Reload();
        }


        public void solveSoduko(String[,] board)
        {
            if(board == null || board.Length == 0)
            {
                return;
            }
            solve(board);
        }

        public bool solve(String[,] board)
        {
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] == ".")
                    {
                        for (char c = '1'; c <= '9'; c++)
                        {
                            if (isValid(board, i, j, c))
                            {
                                board[i, j] = c.ToString();

                                if (solve(board))
                                {
                                    final = board;
                                    return true;
                                }
                                else
                                {
                                    board[i, j] = ".";
                                }
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        private static bool isValid(String[,] board, int row, int col, char c)
        {
            for (int i = 0; i < 9; i++)
            {
                //check row  
                if (board[i, col] != "." && board[i, col] == c.ToString())
                {
                    return false;
                }
                //check column  
                if (board[row, i] != "." && board[row, i] == c.ToString())
                {
                    return false;
                }
                //check 3*3 block  
                if (board[3 * (row / 3) + i / 3, 3 * (col / 3) + i % 3] != "." && board[3 * (row / 3) + i / 3, 3 * (col / 3) + i % 3] == c.ToString())
                {
                    return false;
                }
            }
            return true;
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void solve_btn_Click(object sender, EventArgs e)
        {
            if(getBoard() == null)
            {
                MessageBox.Show("There is a mistake on the soduko board. Please check again", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                solveSoduko(getBoard());
                Clear();
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        dataGridView1.Rows[i].Cells[j].Value = final[i, j];
                    }

                }
            }
        }
    }
}
